package br.com.fiap.androidfragment

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import br.com.fiap.androidfragment.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    //Data binding etapa 2
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //   setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonFragmentOne.setOnclicklistener {
            replaceFragment(FragmentOne())

            //TODO: Impl abrir fragment1
        }
        binding.buttonFragmentTwo.setOnclicklistener {

            replaceFragment(FragmentTwo())
            //TODO: Impl abrir fragment2

        }
        binding.buttonActitivy.setOnclicklistener {
            val intent = Intent(packageContext.this, NewActivity::class.java)

            startActivity(intent)
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()

        fragmentTransaction.replace(R.id.fragmentContainerView, fragment)
        fragmentTransaction.commit()
    }
}