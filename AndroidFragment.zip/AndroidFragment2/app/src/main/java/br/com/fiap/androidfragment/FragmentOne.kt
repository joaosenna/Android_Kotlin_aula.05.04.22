package br.com.fiap.androidfragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import br.com.fiap.androidfragment.databinding.FragmentTwoBinding

class FragmentTwo : Fragment() {
    // TODO: Rename and change types of parameters
    lateinit var binding: FragmentTwoBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        container: ViewGroup?
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentTwoBinding.inflate(inflater, container,false)
        val view = binding.root

        return view
    }
}